import random
print("""Kártyajáték (Black Jack)
A gép ellen játszik 1 játékos. Kap kettő lapot, 16 tól megállhat, alatta újat kell húzzon. Ha megállt, akkor a gép megmutatja a lapjait. Az nyer, aki kevesebb lapból közelebb van a 21-hez. Aki túllépte az veszít! 
""")

cards_values=[11,2,3,4,5,6,7,8,9,10,10,10,10]

player_cards = []
dealer_cards = []
Posszeg = 0
Dosszeg = 0

def kiosztD(lista):
    lap = random.choice(cards_values)
    dealer_cards.append(lap)
    cards_values.remove(lap)

for lap in range(1,3):
    kiosztD(dealer_cards)

for lap in range(0,len(dealer_cards),1):
    Dosszeg+=dealer_cards[lap]

def kiosztP(lista):
    lap = random.choice(cards_values)
    player_cards.append(lap)
    cards_values.remove(lap)

for lap in range(1,3):
    kiosztP(player_cards)
print("Az alábbi lapok kerültek hozzád:",player_cards)

for lap in range(0,len(player_cards),1):
    Posszeg+=player_cards[lap]
print("Lapjaid összege:",Posszeg)

utolso=player_cards[-1]

if (Posszeg<21) or (Posszeg==21):
    if Posszeg==21:
        print("A dealer lapjai:", dealer_cards)
        print("Nyertél!")
    else:
        while Posszeg<16:
            kiosztP(player_cards)
            utolso = player_cards[-1]
            Posszeg += utolso
            print("A lapjaid:", player_cards)
            print("Lapjaid összege:", Posszeg)
        if Posszeg==21:
            print("A dealer lapjai:", dealer_cards)
            print("Nyertél!")
        elif Posszeg<21:
            huzol=input("Szeretnél még egy lapot húzni? (igen/nem) ")
            if huzol=="igen":
                kiosztP(player_cards)
                utolso = player_cards[-1]
                Posszeg += utolso
                print("A lapjaid:",player_cards)
                print("Lapjaid összege", Posszeg)
                if (Posszeg > Dosszeg) and (Posszeg <= 21):
                    print("A dealer lapjai:", dealer_cards)
                    print("Nyertél!")
                else:
                    print("A dealer nyert!")
            elif huzol=="nem":
                print("Lapjaid összege", Posszeg)
                print("A dealer lapjai:", dealer_cards)
                if (Posszeg > Dosszeg) and (Posszeg <= 21):
                    print("Nyertél!")
                else:
                    print("A dealer nyert!")
        elif Posszeg>21:
            print("A dealer lapjai:", dealer_cards)
            print("A dealer nyert!")
elif Posszeg>21:
    print("A dealer lapjai:", dealer_cards)
    print("A dealer nyert!")
