# import module
from prettytable import PrettyTable
import random

#felírtam, hogy mi mit üt
"""
ko->gyik,ollo
gyik->spock,papir
spock->ko,ollo
ollo->gyik,papir
papir->ko,spock
"""

#a kiíráshoz szükséges értékeket egy változóba adtam és ez alapján írja ki a végeredményt
jel1="Kő"
jel2="Papír"
jel3="Olló"
jel4="Gyík"
jel5="Spock"

jelek=["Kő","Papír","Olló","Gyík","Spock"]

kor=0
bot1nyeresek=0
bot2nyeresek=0
dontetlen=0

myTable = PrettyTable(["Körök száma(10)","Béla", "Pókember", "A nyertes kézjel"])


#10x játszák le a meccset
while (kor<10):
    bot1 = random.choice(jelek)
    bot2 = random.choice(jelek)
    kor += 1


#megadom, hogy az adott számértékhez melyik kézjel társul


    #itt kezdődik a játék.A szabályok alapján egy elágazás és a hozzájuk tartozó kimenetel kiírása
    if ((bot1=="Kő") and (bot2=="Gyík")) or ((bot2=="Kő") and (bot1=="Gyík")):
        if ((bot1=="Kő") and (bot2=="Gyík")):
            bot1nyeresek+=1
        else:
            bot2nyeresek+=1
        nyerteskezjel=jel1

    elif ((bot1=="Kő") and (bot2=="Olló")) or ((bot2=="Kő") and (bot1=="Olló")):
        if ((bot1=="Kő") and (bot2=="Olló")):
            bot1nyeresek += 1
        else:
            bot2nyeresek += 1
        nyerteskezjel=jel1

    elif ((bot1=="Gyík") and (bot2=="Spock")) or ((bot2=="Gyík") and (bot1=="Spock")):
        if ((bot1=="Gyík") and (bot2=="Spock")):
            bot1nyeresek += 1
        else:
            bot2nyeresek += 1
        nyerteskezjel=jel4

    elif ((bot1=="Gyík") and (bot2=="Papír")) or ((bot2=="Gyík") and (bot1=="Papír")):
        if ((bot1=="Gyík") and (bot2=="Papír")):
            bot1nyeresek += 1
        else:
            bot2nyeresek += 1
        nyerteskezjel=jel4

    elif ((bot1=="Spock") and (bot2=="Kő")) or ((bot2=="Spock") and (bot1=="Kő")):
        if ((bot1=="Spock") and (bot2=="Kő")):
            bot1nyeresek += 1
        else:
            bot2nyeresek += 1
        nyerteskezjel=jel5

    elif ((bot1=="Spock") and (bot2=="Olló")) or ((bot2=="Spock") and (bot1=="Olló")):
        if ((bot1=="Spock") and (bot2=="Olló")):
            bot1nyeresek += 1
        else:
            bot2nyeresek += 1
        nyerteskezjel=jel5

    elif ((bot1=="Olló") and (bot2=="Gyík")) or ((bot2=="Olló") and (bot1=="Gyík")):
        if ((bot1=="Olló") and (bot2=="Gyík")):
            bot1nyeresek += 1
        else:
            bot2nyeresek += 1
        nyerteskezjel=jel3

    elif ((bot1=="Olló") and (bot2=="Papír")) or ((bot2=="Olló") and (bot1=="Papír")):
        if ((bot1=="Olló") and (bot2=="Papír")):
            bot1nyeresek += 1
        else:
            bot2nyeresek += 1
        nyerteskezjel=jel3

    elif ((bot1=="Papír") and (bot2=="Kő")) or ((bot2=="Papír") and (bot1=="Kő")):
        if ((bot1=="Papír") and (bot2=="Kő")):
            bot1nyeresek += 1
        else:
            bot2nyeresek += 1
        nyerteskezjel=jel2

    elif ((bot1=="Papír") and (bot2=="Spock")) or ((bot2=="Papír") and (bot1=="Spock")):
        if ((bot1=="Papír") and (bot2=="Spock")):
            bot1nyeresek += 1
        else:
            bot2nyeresek += 1
        nyerteskezjel=jel2
    elif bot1==bot2:
        dontetlen+=1
        nyerteskezjel=bot1
    myTable.add_row([kor,bot1, bot2, nyerteskezjel])


#A győztes kiírása
if bot1nyeresek>bot2nyeresek:
    nyertes="Béla"
elif bot2nyeresek>bot1nyeresek:
    nyertes="Pókember"
else:
    nyertes="Mindketten nyertek"

myTable.add_row(["Nyerések száma:",bot1nyeresek, bot2nyeresek, dontetlen])
myTable.add_row(["A nyertes:","","",nyertes])
print(myTable)