/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package halallabirintus;

import java.util.Scanner;

/**
 *
 * @author hallgato
 */
public class halallabirintusElagazas {
    public static void main(String[] args) {
        
        System.out.println("Miután öt percet haladtál lassan az alagútban,\n"
                +"egy kőasztalhoz érsz, amely a bal oldali fal mellett áll.\n"
                +"Hat doboz van rajta, egyikükre a te neved festették."
                +"Ha kiakarod nyitni a dobozt, lapozz a 270-re.\n"
                +"Ha inkább tovább haladsz észak felé, lapozz a 66-ra.\n");
           
        Scanner valasz = new Scanner(System.in);
        System.out.println("Kinyitod a dobozt?\n"
                +"(válaszlehetőségek: igen/nem"); 
        String valaszok = valasz.next();
        System.out.println("");
        
        if ("igen".equals(valaszok)){
            System.out.println("270. oldal");
            System.out.println("A doboz teteje könnyedén nyílik.\n"
                + "Benne két aranypénzt találsz, és egy üzenetet, amely egy\n"
                + "kis pergamenen neked szól. Előbb zsebre vágod az aranyakat,\n"
                + "aztán elolvasod az üzenetet: - „Jól tetted. Legalább volt\n"
                + "annyi eszed, hogy megállj és elfogadd az ajándékot. Most\n"
                + "azt tanácsolom neked, hogy keress és használj különféle\n"
                + "tárgyakat, ha sikerrel akarsz áthaladni Halállabirintusomon.”\n"
                + "Azaláírás Szukumvit. Megjegyzed a tanácsot, apródarabokra\n"
                + "téped a pergament, és tovább mész észak felé. Lapozz a 66-ra.");        
        }else if ("nem".equals(valaszok)){
             System.out.println("Továbbhaladsz északra...");
        }
        
        System.out.println("");
        System.out.println("66. oldal");
                System.out.println("Néhány perc gyaloglás után egy elágazáshoz\n"
                + "érsz az alagútban. Egy, a falra festett fehér nyíl nyugatfelé mutat.\n"
                + "A földön nedves lábnyomok jelzik, merre haladtak az előtted járók.\n"
                + "Nehéz biztosan megmondani, de úgy tűnik, hogy három közülük a nyíl\n"
                + "irányába halad, míg egyikük úgy döntött, hogy keletnek megy.\n"
                + "Ha nyugat felé kívánsz menni, lapozz a 293-ra. Ha keletnek,"
                + "lapozz a 56-re.");
                
        System.out.println("");
        Scanner elagazas = new Scanner(System.in);
        System.out.println("Merre felé mész?\n"
                   +"(válaszlehetőségek: nyugat/kelet)"); 
        String elagazasok = elagazas.next();
        System.out.println("");
        
        if ("nyugat".equals(elagazasok)){
            System.out.println("293. oldal");
            System.out.println("A három pár nedves lábnyomot követve az alagút nyugati\n"
                    + "elágazásában hamarosan egy újabb elágazáshoz érsz. Ha továbbmész\n"
                    + "nyugat felé a lábnyomokat követve, lapozz a 137-re. Ha inkább\n"
                    + "észak felé mész a harmadik pár lábnyom után, lapozz a 387-re.");
            
            System.out.println("");
            Scanner elagazas2 = new Scanner(System.in);
            System.out.println("Merre felé mész?\n"
                   +"(válaszlehetőségek: nyugat/eszak)"); 
            String elagazasok2 = elagazas2.next();
            System.out.println("");
            
            if ("nyugat".equals(elagazasok2)){
                System.out.println("137. oldal");
                System.out.println("Ahogy végigmész az alagúton, csodálkozva látod,\n"
                        + "hogy egy jókora vasharang csüng alá a boltozatról.");
                System.out.println("");
                System.out.println("A kalandod itt most nem folytatódik tovább, de még nincs vége...");
            }else if ("eszak".equals(elagazasok2)){
                System.out.println("387. oldal");
                System.out.println("Hallod, hogy elölről súlyos lépések közelednek.\n"
                        + "Egy széles, állatbőrökbe öltözött, kőbaltás, primitívlény\n"
                        + "lép elő. Ahogy meglát, morog, a földre köp, majd a kőbaltát\n"
                        + "felemelve közeledik, és mindennek kinéz, csak barátságosnak nem.\n"
                        + "Előhúzod kardodat, és felkészülsz, hogy megküzdj a Barlangi Emberrel.");
                System.out.println("Barlangi Ember ÜGYESSÉG 7 ÉLETERŐ 7");
                System.out.println("");
                System.out.println("A kalandod itt most nem folytatódik tovább, de még nincs vége...");
            }
        }else if("kelet".equals(elagazasok)){
            System.out.println("56. oldal");
            System.out.println("Látod, hogy az akadály egy széles, barna, sziklaszerű\n"
                    + "tárgy. Megérinted, és meglepve tapasztalod, hogy lágy, szivacsszerű.\n"
                    + "Ha át szeretnél mászni rajta, lapozz a 373-ra. Ha ketté akarod\n"
                    + "vágni a kardoddal, lapozz a 215-re.");

            System.out.println("");
            Scanner elagazas3 = new Scanner(System.in);
            System.out.println("Átmászol rajta vagy kettévágod?\n"
                   +"(válaszlehetőségek: atmaszom/kettevagom)"); 
            String elagazasok3 = elagazas3.next();
            System.out.println("");
            
            if ("atmaszom".equals(elagazasok3)){
                System.out.println("373. oldal");
                System.out.println("Fölmászol a lágy sziklára, attól tartasz, hogy bár-melyik\n"
                        + "pillanatban elnyelhet. Nehéz átvergődni rajta, mert puha anyagában\n"
                        + "alig tudod a lábadat emelni, de végül átvergődsz rajta. Megkönnyebbülten\n"
                        + "érsz újra szilárd talajra, és fordulsz kelet felé.");
                System.out.println("");
                System.out.println("A kalandod itt most nem folytatódik tovább, de még nincs vége...");
            }else if ("kettevagom".equals(elagazasok3)){
                System.out.println("215. oldal");
                System.out.println("Kardod könnyedén áthatol a spóragolyó vékonykülső burkán.\n"
                        + "Sűrű barna spórafelhő csap ki a golyóból, és körülvesz. Némelyik\n"
                        + "spóra a bőrödhöz tapad, és rettenetes viszketést okoz. Nagy daganatok\n"
                        + "nőnek az arcodon és karodon, és a bőröd mintha égne. 2 ÉLETERŐ pontot\n"
                        + "veszítesz. Vadul vakarózva átléped a leeresztett golyót, és keletnek veszed az utad.");
                System.out.println("");
                System.out.println("A kalandod itt most nem folytatódik tovább, de még nincs vége...");
            }
        }
    }   
 }
