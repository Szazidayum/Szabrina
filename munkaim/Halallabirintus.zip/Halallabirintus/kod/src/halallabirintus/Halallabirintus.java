/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package halallabirintus;

import java.util.Random;

/**
 *
 * @author hallgato
 */
public class Halallabirintus {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Random rnd = new Random();
        Random rnd2 = new Random();
        
        int also=1, felso=6;
        int EnUgyesseg = (rnd.nextInt(felso)+also)+6;
        int EnEletero = (rnd.nextInt(felso)+also)+(rnd.nextInt(felso)+also)+12;
        int EnSzerencse = (rnd.nextInt(felso)+also)+6;
        System.out.println(EnUgyesseg+" "+EnEletero+" "+EnSzerencse);
        
        int TeremtmenyUgyesseg = (rnd.nextInt(felso)+also)+6;
        int TeremtmenyEletero = (rnd.nextInt(felso)+also)+(rnd.nextInt(felso)+also)+12;
        int TeremtmenySzerencse = (rnd.nextInt(felso)+also)+6;
        System.out.println(TeremtmenyUgyesseg+" "+TeremtmenyEletero+" "+TeremtmenySzerencse);
        
     
        System.out.println("harc");
        int TeremtmenyTamadoero = (rnd.nextInt(felso)+also)+(rnd.nextInt(felso)+also)+TeremtmenyUgyesseg;
        int EnTamadoero = (rnd.nextInt(felso)+also)+(rnd.nextInt(felso)+also)+EnUgyesseg;
        System.out.println(TeremtmenyTamadoero+" "+EnTamadoero);
        
        
       int ero1 = EnEletero;
       int ero2 = TeremtmenyEletero;
        while (EnEletero==0 || TeremtmenyEletero==0){
            if (TeremtmenyTamadoero==EnTamadoero){
                TeremtmenyTamadoero = (rnd.nextInt(felso)+also)+(rnd.nextInt(felso)+also)+TeremtmenyUgyesseg;
                EnTamadoero = (rnd.nextInt(felso)+also)+(rnd.nextInt(felso)+also)+EnUgyesseg;
            }else if (TeremtmenyTamadoero>EnTamadoero) {
                ero1 = (EnEletero-2);
            }else if(TeremtmenyTamadoero<EnTamadoero){
                ero2=(TeremtmenyEletero-2);
            }
        
    }
        System.out.println(ero1+" "+ero2);
    }
}
